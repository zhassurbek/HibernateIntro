create function country_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
        IF NEW.country_name IS NULL THEN
            RAISE EXCEPTION 'country_name cannot be null';
        END IF;
        IF NEW.continent IS NULL THEN
            RAISE EXCEPTION '% cannot have null continent', NEW.country_name;
        END IF;

        -- Кто будет работать, если за это надо будет платить?
        IF NEW.avg_price < 0 THEN
            RAISE EXCEPTION '% cannot have a negative avg_price', NEW.country_name;
        END IF;

        -- Запомнить, кто и когда изменил запись
        NEW.last_date := current_timestamp;
        NEW.last_user := current_user;
        RETURN NEW;
    END;
$$;

alter function country_trigger() owner to postgres;

